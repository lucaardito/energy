package it.bbqcode.energy;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class White extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_white);
		if (BuildConfig.DEBUG) {
			Log.d("DEBUG", "Debug Active");
		}
	}
}
