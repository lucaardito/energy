package it.bbqcode.energy.image.sd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.widget.ImageView;
import android.widget.Toast;
import it.bbqcode.energy.image.sd.R;

public class ImageActivity extends Activity {
	
	private static final int REQUEST_READ_STORAGE = 100;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image);

		String pathName = Environment.getExternalStorageDirectory().getPath() + "/Pictures/lp1.png";

		boolean hasPermission = (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);
		if (!hasPermission) {
			requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_READ_STORAGE);
		}

		((ImageView) findViewById(R.id.imageView)).setImageBitmap(BitmapFactory.decodeFile(pathName));

		// Use this method if the source image causes crash (Out of Memory Exception)
		//((ImageView) findViewById(R.id.imageView)).setImageBitmap(decodeFile(img));
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
	    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	    switch (requestCode){
	        case REQUEST_READ_STORAGE: {
	            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
	            	Toast.makeText(getApplicationContext(), "The app was allowed to read your storage. From the next start, the application will function properly.", Toast.LENGTH_LONG).show();
	            } else{
	                Toast.makeText(getApplicationContext(), "The app was not allowed to read your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
	            }
	        }
	    }
	}

	// Decodes image and scales it to reduce memory consumption
	@SuppressWarnings("unused")
	private Bitmap decodeFile(File f){
		Bitmap b = null;
		int IMAGE_MAX_SIZE = 2048; // Adjust this if necessary
		try {
			//Decode image size
			BitmapFactory.Options o = new BitmapFactory.Options();
			o.inJustDecodeBounds = true;

			FileInputStream fis = new FileInputStream(f);
			BitmapFactory.decodeStream(fis, null, o);
			fis.close();

			int scale = 1;
			if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
				scale = (int)Math.pow(2, (int) Math.ceil(Math.log(IMAGE_MAX_SIZE / 
						(double) Math.max(o.outHeight, o.outWidth)) / Math.log(0.5)));
			}

			//Decode with inSampleSize
			BitmapFactory.Options o2 = new BitmapFactory.Options();
			o2.inSampleSize = scale;
			fis = new FileInputStream(f);
			b = BitmapFactory.decodeStream(fis, null, o2);
			fis.close();
		} catch (IOException e) {}
		return b;
	}
}
