package it.bbqcode.energy.empty;

import android.app.Activity;
import android.os.Bundle;

public class White extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/*setContentView(R.layout.activity_white);
		if (BuildConfig.DEBUG) {
			Log.d("DEBUG", "Debug Active");
		}*/
	}
}
