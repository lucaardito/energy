package it.bbqcode.energy.image;

import android.app.Activity;
import android.os.Bundle;
import it.bbqcode.energy.image.R;

public class ImageActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image);
	}
}
