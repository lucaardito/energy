/** Automatically generated file. DO NOT MODIFY */
package ib.bbqcode.energy.image;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}